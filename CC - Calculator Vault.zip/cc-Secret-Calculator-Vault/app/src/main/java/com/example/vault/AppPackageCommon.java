package com.example.vault;

public class AppPackageCommon {
    public static String AppPackageName = "com.example.vault";

}
