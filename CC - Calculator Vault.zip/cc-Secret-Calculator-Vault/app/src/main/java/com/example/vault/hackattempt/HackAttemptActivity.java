package com.example.vault.hackattempt;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.appcompat.widget.Toolbar;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Iterator;
import com.example.vault.R;
import com.example.vault.audio.BaseActivity;
import com.example.vault.features.MainiFeaturesActivity;
import com.example.vault.panicswitch.AccelerometerManager;
import com.example.vault.panicswitch.PanicSwitchActivityMethods;
import com.example.vault.panicswitch.PanicSwitchCommon;
import com.example.vault.securitylocks.SecurityLocksCommon;

public class HackAttemptActivity extends BaseActivity {
    public static ProgressDialog myProgressDialog;
    ListView HackAttemptListView;
    ArrayList<HackAttemptEntity> hackAttemptEntitys;
    HackAttemptListAdapter hackAttemptListAdapter;
    Handler handle = new Handler() {
        public void handleMessage(Message message) {
            if (message.what == 2) {
                HackAttemptActivity.this.hideProgress();
            } else if (message.what == 3) {
                HackAttemptActivity.this.hideProgress();
                HackAttemptActivity.this.ChangeCheckboxVisibility(false);
                Toast.makeText(HackAttemptActivity.this, R.string.toast_more_hack_attempts_deleted, Toast.LENGTH_SHORT).show();
                SecurityLocksCommon.IsAppDeactive = false;
                HackAttemptActivity.this.startActivity(new Intent(HackAttemptActivity.this, HackAttemptActivity.class));
                HackAttemptActivity.this.overridePendingTransition(17432576, 17432577);
                HackAttemptActivity.this.finish();
            }
            super.handleMessage(message);
        }
    };
    boolean isEditMode = false;
    ImageView iv_hacker_image;
    LinearLayout ll_Delete;
    LinearLayout ll_DeleteAndSelectAll;
    LayoutParams ll_DeleteAndSelectAll_Params;
    LayoutParams ll_DeleteAndSelectAll_Params_hidden;
    LinearLayout ll_HackAttemptTopBaar;
    LinearLayout ll_No_hackattempts;
    LinearLayout ll_SelectAll;
    LinearLayout ll_background;
    LinearLayout ll_hackattempts;
    boolean selectAll = false;
    private SensorManager sensorManager;
    private Toolbar toolbar;

    public void onAccelerationChanged(float f, float f2, float f3) {
    }

    public void onAccuracyChanged(Sensor sensor, int i) {
    }


    public void showDeleteProgress() {
        myProgressDialog = ProgressDialog.show(this, null, "Please be patient... this may take a few moments...", true);
    }


    public void hideProgress() {
        ProgressDialog progressDialog = myProgressDialog;
        if (progressDialog != null && progressDialog.isShowing()) {
            myProgressDialog.dismiss();
        }
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.hack_attempt_activity);
        SecurityLocksCommon.IsAppDeactive = true;
        getWindow().addFlags(128);
        Typeface createFromAsset = Typeface.createFromAsset(getAssets(), "ebrima.ttf");
        this.sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        this.toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(this.toolbar);
        getSupportActionBar().setTitle((CharSequence) "Hack Attempts");
        this.toolbar.setNavigationIcon((int) R.drawable.ic_top_back_icon);
        this.toolbar.setNavigationOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                HackAttemptActivity.this.btnBackonClick();
            }
        });
        this.ll_background = (LinearLayout) findViewById(R.id.ll_background);
        this.ll_DeleteAndSelectAll_Params = new LayoutParams(-1, -2);
        this.ll_DeleteAndSelectAll_Params_hidden = new LayoutParams(-2, 0);
        this.ll_DeleteAndSelectAll = (LinearLayout) findViewById(R.id.ll_DeleteAndSelectAll);
        this.ll_DeleteAndSelectAll.setVisibility(View.INVISIBLE);
        this.ll_DeleteAndSelectAll.setLayoutParams(this.ll_DeleteAndSelectAll_Params_hidden);
        this.ll_HackAttemptTopBaar = (LinearLayout) findViewById(R.id.ll_HackAttemptTopBaar);
        this.ll_Delete = (LinearLayout) findViewById(R.id.ll_Delete);
        this.ll_SelectAll = (LinearLayout) findViewById(R.id.ll_SelectAll);
        this.ll_No_hackattempts = (LinearLayout) findViewById(R.id.ll_No_hackattempts);
        this.ll_hackattempts = (LinearLayout) findViewById(R.id.ll_hackattempts);
        this.ll_No_hackattempts.setVisibility(View.VISIBLE);
        this.ll_hackattempts.setVisibility(View.INVISIBLE);
        this.iv_hacker_image = (ImageView) findViewById(R.id.iv_hackattempt_item);
        this.HackAttemptListView = (ListView) findViewById(R.id.HackAttemptListView);
        ((TextView) findViewById(R.id.HackAttemptTopBaar_Title)).setTypeface(createFromAsset);
        TextView textView = (TextView) findViewById(R.id.lblSelectAll);
        ((TextView) findViewById(R.id.lblDelete)).setTypeface(createFromAsset);
        textView.setTypeface(createFromAsset);
        this.HackAttemptListView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                if (!HackAttemptActivity.this.isEditMode) {
                    SecurityLocksCommon.IsAppDeactive = false;
                    Intent intent = new Intent(HackAttemptActivity.this, HackAttemptDetailActivity.class);
                    intent.putExtra("HackerImagePath", ((HackAttemptEntity) HackAttemptActivity.this.hackAttemptEntitys.get(i)).GetImagePath());
                    intent.putExtra("WrongPass", ((HackAttemptEntity) HackAttemptActivity.this.hackAttemptEntitys.get(i)).GetWrongPassword());
                    intent.putExtra("DateTime", ((HackAttemptEntity) HackAttemptActivity.this.hackAttemptEntitys.get(i)).GetHackAttemptTime());
                    intent.putExtra("Position", i);
                    HackAttemptActivity.this.startActivity(intent);
                    HackAttemptActivity.this.finish();
                }
            }
        });
        this.HackAttemptListView.setOnItemLongClickListener(new OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long j) {
                ((HackAttemptEntity) HackAttemptActivity.this.hackAttemptEntitys.get(i)).SetIsCheck(Boolean.valueOf(true));
                HackAttemptActivity.this.ll_DeleteAndSelectAll.setVisibility(View.VISIBLE);
                HackAttemptActivity.this.ll_DeleteAndSelectAll.setLayoutParams(HackAttemptActivity.this.ll_DeleteAndSelectAll_Params);
                HackAttemptActivity hackAttemptActivity = HackAttemptActivity.this;
                HackAttemptListAdapter hackAttemptListAdapter = new HackAttemptListAdapter(hackAttemptActivity, 17367043, hackAttemptActivity.hackAttemptEntitys, true, Boolean.valueOf(false));
                hackAttemptActivity.hackAttemptListAdapter = hackAttemptListAdapter;
                HackAttemptActivity.this.HackAttemptListView.setAdapter(HackAttemptActivity.this.hackAttemptListAdapter);
                HackAttemptActivity.this.hackAttemptListAdapter.notifyDataSetChanged();
                return true;
            }
        });
        this.ll_Delete.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (HackAttemptActivity.this.hackAttemptEntitys == null) {
                    return;
                }
                if (HackAttemptActivity.this.IsFileCheck()) {
                    HackAttemptActivity.this.DeleteHackAttept();
                } else {
                    Toast.makeText(HackAttemptActivity.this, R.string.toast_unselectphotomsg_Hackattempts, Toast.LENGTH_SHORT).show();
                }
            }
        });
        this.ll_SelectAll.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (HackAttemptActivity.this.selectAll) {
                    HackAttemptActivity.this.selectAll = false;
                } else {
                    HackAttemptActivity.this.selectAll = true;
                }
                Iterator it = HackAttemptActivity.this.hackAttemptEntitys.iterator();
                while (it.hasNext()) {
                    ((HackAttemptEntity) it.next()).SetIsCheck(Boolean.valueOf(HackAttemptActivity.this.selectAll));
                }
                HackAttemptActivity hackAttemptActivity = HackAttemptActivity.this;
                HackAttemptListAdapter hackAttemptListAdapter = new HackAttemptListAdapter(hackAttemptActivity, 17367043, hackAttemptActivity.hackAttemptEntitys, true, Boolean.valueOf(HackAttemptActivity.this.selectAll));
                hackAttemptActivity.hackAttemptListAdapter = hackAttemptListAdapter;
                HackAttemptActivity.this.HackAttemptListView.setAdapter(HackAttemptActivity.this.hackAttemptListAdapter);
                HackAttemptActivity.this.hackAttemptListAdapter.notifyDataSetChanged();
            }
        });
        BindHackAttempsList();
    }

    public void btnBackonClick() {
        SecurityLocksCommon.IsAppDeactive = false;
        startActivity(new Intent(this, MainiFeaturesActivity.class));
        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        HackAttemptActivity.this.btnBackonClick();
    }

    public void DeleteHackAttept() {
        final Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setContentView(R.layout.confirmation_message_box);
        dialog.setCancelable(true);
        LinearLayout linearLayout = (LinearLayout) dialog.findViewById(R.id.ll_background);
        TextView textView = (TextView) dialog.findViewById(R.id.tvmessagedialogtitle);
        textView.setTypeface(Typeface.createFromAsset(getAssets(), "ebrima.ttf"));
        textView.setText("Are you sure you want to delete selected Hack Attempts?");
        ((LinearLayout) dialog.findViewById(R.id.ll_Ok)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                HackAttemptActivity.this.showDeleteProgress();
                new Thread() {
                    public void run() {
                        try {
                            dialog.dismiss();
                            HackAttemptActivity.this.Delete();
                            Message message = new Message();
                            message.what = 3;
                            HackAttemptActivity.this.handle.sendMessage(message);
                        } catch (Exception unused) {
                            Message message2 = new Message();
                            message2.what = 2;
                            HackAttemptActivity.this.handle.sendMessage(message2);
                        }
                    }
                }.start();
                dialog.dismiss();
            }
        });
        ((LinearLayout) dialog.findViewById(R.id.ll_Cancel)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }


    public void Delete() {
        Iterator it = new ArrayList(this.hackAttemptEntitys).iterator();
        while (it.hasNext()) {
            HackAttemptEntity hackAttemptEntity = (HackAttemptEntity) it.next();
            if (hackAttemptEntity.GetIsCheck()) {
                this.hackAttemptEntitys.remove(hackAttemptEntity);
            }
        }
        HackAttemptsSharedPreferences.GetObject(this).SetHackAttemptObject(this.hackAttemptEntitys);
    }


    public boolean IsFileCheck() {
        Iterator it = new ArrayList(this.hackAttemptEntitys).iterator();
        while (it.hasNext()) {
            if (((HackAttemptEntity) it.next()).GetIsCheck()) {
                return true;
            }
        }
        return false;
    }

    private void BindHackAttempsList() {
        this.hackAttemptEntitys = HackAttemptsSharedPreferences.GetObject(getApplicationContext()).GetHackAttemptObject();
        ArrayList<HackAttemptEntity> arrayList = this.hackAttemptEntitys;
        if (arrayList != null) {
            if (arrayList.size() > 0) {
                this.ll_No_hackattempts.setVisibility(View.INVISIBLE);
                this.ll_hackattempts.setVisibility(View.VISIBLE);
            }
            HackAttemptListAdapter hackAttemptListAdapter2 = new HackAttemptListAdapter(this, 17367043, this.hackAttemptEntitys, false, Boolean.valueOf(false));
            this.hackAttemptListAdapter = hackAttemptListAdapter2;
            this.HackAttemptListView.setAdapter(this.hackAttemptListAdapter);
            this.hackAttemptListAdapter.notifyDataSetChanged();
            return;
        }
        this.ll_No_hackattempts.setVisibility(View.VISIBLE);
        this.ll_hackattempts.setVisibility(View.INVISIBLE);
    }


    public void ChangeCheckboxVisibility(boolean z) {
        if (z) {
            this.ll_DeleteAndSelectAll.setVisibility(View.VISIBLE);
            this.ll_DeleteAndSelectAll.setLayoutParams(this.ll_DeleteAndSelectAll_Params);
        } else {
            this.ll_DeleteAndSelectAll.setVisibility(View.INVISIBLE);
            this.ll_DeleteAndSelectAll.setLayoutParams(this.ll_DeleteAndSelectAll_Params_hidden);
        }
        Iterator it = this.hackAttemptEntitys.iterator();
        while (it.hasNext()) {
            ((HackAttemptEntity) it.next()).SetIsCheck(Boolean.valueOf(z));
        }
        HackAttemptListAdapter hackAttemptListAdapter2 = new HackAttemptListAdapter(this, 17367043, this.hackAttemptEntitys, z, Boolean.valueOf(false));
        this.hackAttemptListAdapter = hackAttemptListAdapter2;
        this.HackAttemptListView.setAdapter(this.hackAttemptListAdapter);
        this.hackAttemptListAdapter.notifyDataSetChanged();
    }

    public void onShake(float f) {
        if (PanicSwitchCommon.IsFlickOn || PanicSwitchCommon.IsShakeOn) {
            PanicSwitchActivityMethods.SwitchApp(this);
        }
    }

    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == 8 && sensorEvent.values[0] == 0.0f && PanicSwitchCommon.IsPalmOnFaceOn) {
            PanicSwitchActivityMethods.SwitchApp(this);
        }
    }


    public void onPause() {
        this.sensorManager.unregisterListener(this);
        if (AccelerometerManager.isListening()) {
            AccelerometerManager.stopListening();
        }
        if (SecurityLocksCommon.IsAppDeactive) {
            finish();
            System.exit(0);
        }
        if (SecurityLocksCommon.IsAppDeactive) {
            finish();
            System.exit(0);
        }
        super.onPause();
    }


    public void onResume() {
        if (AccelerometerManager.isSupported(this)) {
            AccelerometerManager.startListening(this);
        }
        SensorManager sensorManager2 = this.sensorManager;
        sensorManager2.registerListener(this, sensorManager2.getDefaultSensor(8), 3);
        super.onResume();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i == 4) {
            if (this.isEditMode) {
                this.isEditMode = false;
                ChangeCheckboxVisibility(false);
            }
//            SecurityLocksCommon.IsAppDeactive = false;
//            startActivity(new Intent(this, MoreActivity.class));
//            finish();
            HackAttemptActivity.this.btnBackonClick();
        }
        return super.onKeyDown(i, keyEvent);
    }
}
