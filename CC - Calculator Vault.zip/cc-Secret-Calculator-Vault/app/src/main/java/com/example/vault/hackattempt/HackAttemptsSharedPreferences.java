package com.example.vault.hackattempt;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;

public class HackAttemptsSharedPreferences {
    private static String _fileName = "HackAttempts";
    private static String _hackAttemptObject = "HackAttemptObject";
    static Context context;
    private static HackAttemptsSharedPreferences hackAttemptsSharedPreferences;
    static SharedPreferences myPrefs;

    private HackAttemptsSharedPreferences() {
    }

    public static HackAttemptsSharedPreferences GetObject(Context context2) {
        if (hackAttemptsSharedPreferences == null) {
            hackAttemptsSharedPreferences = new HackAttemptsSharedPreferences();
        }
        context = context2;
        myPrefs = context.getSharedPreferences(_fileName, 0);
        return hackAttemptsSharedPreferences;
    }

    public void SetHackAttemptObject(ArrayList<HackAttemptEntity> arrayList) {
        Editor edit = myPrefs.edit();
        edit.putString("HackAttemptObject", new Gson().toJson((Object) arrayList));
        edit.commit();
    }

    public ArrayList<HackAttemptEntity> GetHackAttemptObject() {
        new Gson();
        return (ArrayList) new Gson().fromJson(myPrefs.getString("HackAttemptObject", "").toString(), new TypeToken<ArrayList<HackAttemptEntity>>() {
        }.getType());
    }
}
