package com.example.vault.hackattempt;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import com.example.vault.securitylocks.SecurityLocksSharedPreferences;

public class HackAttemptMethods {
    static ArrayList<HackAttemptEntity> HackAttemptEntitys;

    public void AddHackAttempToSharedPreference(Context context, String str, String str2) {
        SecurityLocksSharedPreferences GetObject = SecurityLocksSharedPreferences.GetObject(context);
        long currentTimeMillis = System.currentTimeMillis();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMM dd,yyyy HH:edit_share_btn");
        Date date = new Date(currentTimeMillis);
        System.out.println(simpleDateFormat.format(date));
        HackAttemptEntity hackAttemptEntity = new HackAttemptEntity();
        hackAttemptEntity.SetLoginOption(GetObject.GetLoginType());
        hackAttemptEntity.SetWrongPassword(str);
        hackAttemptEntity.SetImagePath(str2);
        hackAttemptEntity.SetHackAttemptTime(date.toString());
        hackAttemptEntity.SetIsCheck(Boolean.valueOf(false));
        HackAttemptEntitys = new ArrayList<>();
        HackAttemptsSharedPreferences GetObject2 = HackAttemptsSharedPreferences.GetObject(context);
        HackAttemptEntitys = GetObject2.GetHackAttemptObject();
        ArrayList<HackAttemptEntity> arrayList = HackAttemptEntitys;
        if (arrayList == null) {
            HackAttemptEntitys = new ArrayList<>();
            HackAttemptEntitys.add(hackAttemptEntity);
        } else {
            arrayList.add(hackAttemptEntity);
        }
        GetObject2.SetHackAttemptObject(HackAttemptEntitys);
    }

    public static Bitmap DecodeFile(File file) {
        try {
            Options options = new Options();
            int i = 1;
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(new FileInputStream(file), null, options);
            while ((options.outWidth / i) / 2 >= 70 && (options.outHeight / i) / 2 >= 70) {
                i *= 2;
            }
            Options options2 = new Options();
            options2.inSampleSize = i;
            return BitmapFactory.decodeStream(new FileInputStream(file), null, options2);
        } catch (FileNotFoundException unused) {
            return null;
        }
    }

    public static byte[] GetBitmapAsByteArray(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(CompressFormat.PNG, 0, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }
}
