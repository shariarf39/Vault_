package com.example.vault;

import android.app.Activity;

public class SplashActivity extends Activity {
}
