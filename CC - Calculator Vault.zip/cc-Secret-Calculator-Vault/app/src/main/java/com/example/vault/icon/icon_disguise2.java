package com.example.vault.icon;

public class icon_disguise2 {
}
