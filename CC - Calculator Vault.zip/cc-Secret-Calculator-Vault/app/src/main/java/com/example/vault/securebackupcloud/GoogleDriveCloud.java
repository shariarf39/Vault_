package com.example.vault.securebackupcloud;

import java.util.ArrayList;

public class GoogleDriveCloud implements ISecureBackupCloud {
    public void CreateFolder(String str) {
    }

    public void CreateFolder(BackupCloudEnt backupCloudEnt) {
    }

    public void CreateFolderStructure() {
    }

    public void CreateLocalFolder(BackupCloudEnt backupCloudEnt) {
    }

    public void DownloadFile(BackupCloudEnt backupCloudEnt) {
    }

    public void GetFiles(String str) {
    }

    public ArrayList<BackupCloudEnt> GetFolders(String str) {
        return null;
    }

    public void UploadFile(BackupCloudEnt backupCloudEnt) {
    }
}
