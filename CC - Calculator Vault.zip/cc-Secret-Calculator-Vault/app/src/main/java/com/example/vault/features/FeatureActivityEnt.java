package com.example.vault.features;

public class FeatureActivityEnt {
    private String _featureName;
    private int _feature_Icon;

    public String get_featureName() {
        return this._featureName;
    }

    public void set_featureName(String str) {
        this._featureName = str;
    }

    public int get_feature_Icon() {
        return this._feature_Icon;
    }

    public void set_feature_Icon(int i) {
        this._feature_Icon = i;
    }
}
