package com.example.vault.photo;

public class ImageData {
    private String imgPath;

    public String getImgPath() {
        return this.imgPath;
    }

    public void setImgPath(String str) {
        this.imgPath = str;
    }
}
