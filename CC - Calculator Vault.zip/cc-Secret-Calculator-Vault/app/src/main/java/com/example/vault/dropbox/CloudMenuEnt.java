package com.example.vault.dropbox;

public class CloudMenuEnt {
    private int _CloudHeading;
    private int _drawable;

    public void SetCloudHeading(int i) {
        this._CloudHeading = i;
    }

    public int GetCloudHeading() {
        return this._CloudHeading;
    }

    public void SetDrawable(int i) {
        this._drawable = i;
    }

    public int GetDrawable() {
        return this._drawable;
    }
}
