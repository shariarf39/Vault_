package vocsy.ads;

public interface SmartListener {
    void onFinish(boolean success);
}
