package vocsy.ads;

public interface OnEventListener {
    void onEvent(boolean purchased);
}
